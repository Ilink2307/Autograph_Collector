create FUNCTION register_user2(p_email_user IN accounts.email%TYPE, p_username IN accounts.username%TYPE, 
    p_password IN accounts.pass%TYPE) RETURN VARCHAR2 AS
    
    mesaj VARCHAR2(50);
    counter INTEGER;

BEGIN
    mesaj := p_email_user || p_username || p_password;

    IF (NOT p_email_user IS NULL AND NOT p_username IS NULL AND NOT p_password IS NULL) THEN
        SELECT COUNT(*) INTO counter FROM accounts WHERE email = p_email_user;
        IF (counter = 0) THEN
            INSERT INTO accounts VALUES (p_email_user, p_username, p_password);
            RETURN 0;
        END IF;
        RETURN 1;
    END IF;    
    RETURN 2;
END register_user2;
/

