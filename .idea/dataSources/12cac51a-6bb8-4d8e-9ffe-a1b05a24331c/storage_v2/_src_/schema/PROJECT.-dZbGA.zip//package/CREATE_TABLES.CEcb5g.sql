create PACKAGE create_tables AS
    PROCEDURE create_tags_table(p_id_autograph IN number);
    PROCEDURE create_autographs_table(p_id_user IN accounts.id_user%TYPE);
END;
/

