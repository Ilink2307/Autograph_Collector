create function compute_points(p_author in number, p_item in varchar2, p_mentions in varchar2) 
    return integer as
    
    v_author_importance integer;
    v_item_importance integer;
    v_has_mentions boolean;
    v_points integer;

    counter integer;
begin

    if (p_mentions is not null) then
        v_has_mentions := true;
    else
        v_has_mentions := false;
    end if;

    select count(*) into counter from autograph_authors where author=p_author;
    if (counter != 0) then 
        select importance into v_author_importance from autograph_authors where author=p_author;
    else 
        v_author_importance := 5;
    end if;

    select count(*) into counter from items where item_name=p_item;
    if (counter != 0) then 
        select importance into v_item_importance from items where item_name=p_item;
    else 
        v_item_importance := 2;
    end if;

    v_points := 2;--70/100*v_author_importance + 30/100*v_item_importance;
    if (v_has_mentions = true) then
        v_points := 2;--v_points + 5/100*v_points;
    end if;

    return v_points;

end compute_points;
/

