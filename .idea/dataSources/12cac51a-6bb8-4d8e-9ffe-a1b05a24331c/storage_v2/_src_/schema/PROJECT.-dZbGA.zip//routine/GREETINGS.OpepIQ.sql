create PROCEDURE greetings 
AS 
BEGIN 
   dbms_output.put_line('Hello World!'); 
END;
/

