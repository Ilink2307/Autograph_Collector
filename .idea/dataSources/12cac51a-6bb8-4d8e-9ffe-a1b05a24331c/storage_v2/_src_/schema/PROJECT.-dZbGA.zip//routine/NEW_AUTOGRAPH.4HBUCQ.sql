create function new_autograph ( 
    p_id_user in varchar2, p_author in number, p_item in varchar2,
    p_moment in varchar2, p_mentions in varchar2) return varchar2 as

    counter integer;
    v_id_autograph integer;
    v_points integer := 0;
begin

    select count(*) into counter from autographs;
    v_id_autograph := counter+1;

    if (p_id_user is not null and p_author is not null) then
        insert into autographs values (v_id_autograph, p_id_user, p_author, p_item, 
            p_moment, p_mentions, v_points);
        return '0'; -- successfully inserted
    end if;
    return '1'; -- incorrect entry
end new_autograph;
/

