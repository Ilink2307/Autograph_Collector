create PACKAGE user_package AS
    procedure register_user(p_email_user IN VARCHAR2, p_username IN VARCHAR2, 
        p_password IN VARCHAR2, return_code out number);

    procedure login(p_email IN VARCHAR2, p_password IN VARCHAR2, return_code out number);
    function count_logged_users(p_email in varchar2, p_password in varchar2) return integer;
    function count_registered_users(p_email in varchar2) return integer;

END;
/

