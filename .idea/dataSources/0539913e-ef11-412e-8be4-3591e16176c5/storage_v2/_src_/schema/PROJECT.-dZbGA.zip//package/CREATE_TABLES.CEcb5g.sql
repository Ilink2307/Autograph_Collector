create PACKAGE create_tables AS
    PROCEDURE create_tags_table(p_id_autograph IN autographs.id_autograph%TYPE);
    PROCEDURE create_autographs_table(p_id_user IN accounts.email%TYPE);
END;
/

