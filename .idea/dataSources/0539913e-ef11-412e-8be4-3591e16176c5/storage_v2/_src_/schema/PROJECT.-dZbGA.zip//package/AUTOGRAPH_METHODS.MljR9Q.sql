create PACKAGE autograph_methods AS
    function compute_points(p_id_author in number, p_id_item in number, p_mentions in varchar2) return integer;
    function new_autograph ( 
        p_id_user in number, p_author in number, p_item in varchar2,
        p_moment in varchar2, p_mentions in varchar2) return varchar2;
    procedure new_tag (p_id_auto in number, p_id_tag in number);
    procedure new_autograph_dynamic(
        p_id_user in number, p_id_auto in NUMBER, p_id_author NUMBER,
        p_id_item NUMBER, p_moment VARCHAR2, p_mentions VARCHAR2);
    procedure delete_autograph(p_id_user in number, p_id_auto in number);
END;
/

